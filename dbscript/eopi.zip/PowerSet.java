package eopi;

import org.junit.Test;

public class PowerSet {
	
	public static void printPowerSetSt(String[] set) {
		for(int i=0; i < (1 << set.length);i++) {
			int x = i;
			//用bitmap对应数组元素。找到1所对应元素，并打印
			while(x > 0) {
				//从最低位开始找“1”，找到后计算出对应的indice
				int tar = (int) (Math.log(x & ~(x-1)) /Math.log(2));
				System.out.print("t:"+tar+",x:"+x);
				System.out.print(set[tar]);
				//移除最低位的“1”
				if( (x &= x-1) > 0){
					System.out.print(",");
				}
			}
			System.out.println();
		}
	}
	
	public static void printPowerSet(String[] set) {
		int len = set.length;
		long max = getPower(len)-1;
		long b = 0;
		while( max >=0 ){
			for(int i=0;i<len;i++) {
				b = max >> i & 1;
				if(b == 1){
					System.out.print(set[i]+" ");
				}
			}
			System.out.println();
			max--;
		}
	}
	
	private static long getPower(int len) {
		long n = 1;
		for(int i=0;i<len;i++) {
			n *= 2;
		}
		return n;
	}
	
	@Test
	public void testCase1() {
		String[] set = new String[]{"A","B","C"};
		printPowerSetSt(set);
	}

}
