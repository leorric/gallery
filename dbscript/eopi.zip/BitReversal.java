package eopi;

public class BitReversal {
	
	private long[] precomputed; 
	
	public BitReversal() {
		
	}
	
	public long fastReverse(long x) {
		return precomputed[(int)(x >> 48) & 0xFFFF] |
		precomputed[(int)(x >> 32) & 0xFFFF] << 16 |
		precomputed[(int)(x >> 16) & 0xFFFF] << 32 |
		precomputed[(int)x  & 0xFFFF] << 48 ;
	}
	
	public long reverse(long x) {
		long n = x;
		int len = 0;
		while(n>0) {
			n /= 2;
			len++;
		}
		BitSwap bs = new BitSwap();
		for(int i=0,j=len-1; i<j ; i++,j--) {
			x = bs.swapBit(x, i, j);
		}
		return x;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BitReversal br = new BitReversal();
		long x = br.reverse(11);
		System.out.println(x);
		
		x = br.reverse(21);
		System.out.println(x);
		
		x = br.reverse(14);
		System.out.println(x);
	}

}
