package eopi;

import java.text.ParseException;

import org.junit.Test;

public class StringIntConverter {
	
	
	public static int parseInt(String s) throws ParseException {
		int b = 0;
		int n = 0;
		int multi = 1;
		for(int i=s.length()-1;i>=0;i--,multi*=10) {
			b = s.charAt(i) - '0';
			if(b < 0 || b > 9){
				throw new ParseException(s+" is not valid number",0);
			}
			n += b * multi;
		}
		return n;
	}
	
	@Test
	public void test() throws Exception {
		String s = "1267b3";
		int n = parseInt(s);
		System.out.println(n);
	}
}
