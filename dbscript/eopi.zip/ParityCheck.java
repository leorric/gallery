package eopi;

public class ParityCheck {
	
	public ParityCheck() {
		
	}
	
	public void checkParity(long n) {
		
		int count = 0;
		long bit = 0;
		while(n > 0){
			bit = n & 1;
			if(bit == 1){
				count++;
			}
			n = n >> 1;
		}
//		if(count % 2 == 0) {
//			System.out.println("parity is 0");
//		}else{
//			System.out.println("parity is 1");
//		}
	}
	
	public void checkParity2(long n) {
		short result = 0;
		int i=0;
		while(n!=0) {
			result ^= (n & 1);
			n = n >> 1;
			i++;
		}
		System.out.println("i="+i);
		
//			System.out.println("result is :"+result);
		
	}
	
	
	//平均效率比2高，循环次数小于等于2
	//2是每位检查，次方法是只检查1的位
	public void checkParity3(long n) {
		short result = 0;
		int i=0;
		while(n!=0) {
			result ^= 1;
			//remove least significant bit
			//if n is 10 (1010) , n & (n-1) is 8(1000,the second bit,which was 1,is removed)
			//if n is 8 (1000) , n & (n-1) is 0(0000,the 4th bit,which was 1,is removed)
			n &= (n-1); 
			i++;
		}
//		System.out.println("result is :"+result);
		System.out.println("i="+i);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
