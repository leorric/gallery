package eopi;

public class BitSwap {
	
	
	public int swapBit(int n,int i,int j) {
		if(i == j){
			return n;
		}
		int ithValue = (n >> i) & 1;
		int jthValue = (n >> j) & 1;
		
		if( ithValue == jthValue){
			return n;
		}
		n = n ^ ( 1 << i);
		n = n ^ ( 1 << j);
		return n;
	}
	
	public long swapBit(long n,int i,int j) {
		if( ((n >> i) & 1) != ((n >> j) & 1)){
			n ^= (1L << i) | (1L << j);
		}
		return n;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BitSwap bs = new BitSwap();
		int k = bs.swapBit(10, 2, 3);
		System.out.println("k="+k);
		
		k = bs.swapBit(12, 1, 2);
		System.out.println("k="+k);
		
		k = bs.swapBit(9, 0, 1);
		System.out.println("k="+k);
	}

}
