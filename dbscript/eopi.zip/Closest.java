package eopi;

import org.junit.Assert;
import org.junit.Test;

public class Closest {
	
//	1001
//	1010
	
//	1010
//	1001
//	
//	1011
//	1101
//	
//	1110
//	1101
	public static long getClosestWithSameWeightBriefly(long x) {
		for(int i=0; i< 63; i++) {
			if(  ( (x >> i & 1 ) ^ ( x >> (i+1) & 1 ) )== 1  ) {
				return x ^ ((1L << i) | (1L << i+1));
			}
		}
		return -1;
	}
	
	public static long getClosestWithSameWeight(long x) {
		long l = 0;
		long h = x & 0x01;
		int i=0;
		long tmp = x;
		while(tmp > 0) {
			l = h;
			tmp = tmp >> 1 ;
			h = tmp & 0x01;
			if((l ^ h) == 1) {
				break;
			}
			i++;
		}
		return x ^ ((1L << i+1) | (1L << i));
	}
	
	@Test
	public void testCase1() {
		
		long n = getClosestWithSameWeightBriefly(9);
		Assert.assertTrue(n == 10);
	}
	
	@Test
	public void testCase2() {
		
		long n = getClosestWithSameWeightBriefly(11);
		Assert.assertTrue(n == 13);
	}
	
	@Test
	public void testCase3() {
		
		long n = getClosestWithSameWeightBriefly(1);
		Assert.assertTrue(n == 2);
	}
	
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Cloest c = new Cloest();
//		long n = c.getClosestWithSameWeight(9);
//		System.out.println(n);
//	}
}
